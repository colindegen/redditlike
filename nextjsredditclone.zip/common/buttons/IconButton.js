import Image from "next/Image";
import styles from "./styles/IconButton.module.css";

export default function IconButton({iconSrc,text,fontSize,variant}) {

  return(
    <div>
      {iconSrc != undefined ?
        <button className={styles.iconButton}><Image width="0px" height="0px" layout="responsive" src={iconSrc}></Image><p>{text}</p></button>
              :
        <button className={styles.iconButton}><p styles={{display:"inline-block"}}>{text}</p></button>
      }
    </div>
  );
}
