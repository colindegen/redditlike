import FrontPage from "../modules/front-page/FrontPage.js";
import data from "../public/data.json";
import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>Home App</title>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
          <link href="https://fonts.googleapis.com/css2?family=Krona+One&family=Nunito&family=Quicksand&family=Roboto:wght@300&display=swap" rel="stylesheet" />
          <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet" />
      </Head>
      <div>
        <FrontPage data={data}/>
      </div>
    </>
  );
}
