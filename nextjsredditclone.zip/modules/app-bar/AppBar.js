import styles from "./styles/AppBar.module.css";
import AppBarUserDetails from "./AppBarUserDetails";
import AppBarNavigation from "./AppBarNavigation";
import AppBarHeader from "./AppBarHeader";

export default function AppBar() {

  return (
    <div className={styles.appBar}>
      <AppBarHeader />
      <AppBarNavigation />
      <AppBarUserDetails />
    </div>
  )
}
