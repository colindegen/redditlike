import styles from "./styles/AppBarHeader.module.css";

export default function AppBarHeader() {
  return(
    <div className={styles.appBarHeader}>
      <h1>testname</h1>
    </div>
  )
}
